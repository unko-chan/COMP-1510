Kevin Liang, A01353636, B, 2023-02-02

This assignment is 100% complete.


------------------------
Question one (Change) status:

complete

------------------------
Question two (Sqrt) status:

complete

------------------------
Question three (DiscountCalculator) status:

complete

------------------------
Question four (Pack) status:

complete

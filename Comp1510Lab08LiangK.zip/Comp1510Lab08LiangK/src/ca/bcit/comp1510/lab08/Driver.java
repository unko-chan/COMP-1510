package ca.bcit.comp1510.lab08;

/**
 * The Driver class.
 *
 * @author Kevin Liang
 * @version 2023
 */

public class Driver {
    /**
     * Drives the program.
      * @param args unused
     */
    public static void main(String[] args) {
        Games myGame = new Games();
        myGame.play();
    }

}
